# Volume 1 — Description and architecture

What fabric is and how each part works: architecture, services, APIs and runtime infrastructure, with the technologies each part uses. One chapter per part; Volumes 2, 3 and 4 follow these chapters (Rule 5.9).

## 1.1 The product, and how it is built and released

The home chapter for third-party licences is 1.1.7 (Rule 5.8).

- [1.1.1 What fabric is](1.1.1-what-fabric-is.md)
- [1.1.2 Where fabric came from](1.1.2-history.md)
- [1.1.3 Phases](1.1.3-phases.md)
- [1.1.4 Roadmap](1.1.4-roadmap.md)
- [1.1.5 Code conventions](1.1.5-code-conventions.md)
- [1.1.6 What every change must keep working](1.1.6-must-keep-working.md)
- [1.1.7 Third-party licences](1.1.7-third-party-licences.md)
- [1.1.8 About the settings](1.1.8-about-settings.md)
- [1.1.9 Optional parts](1.1.9-optional-parts.md)

## 1.2 Architecture and the host

The home chapter for security is 1.2.8 (Rule 5.8).

- [1.2.1 System topology and request flows](1.2.1-topology.md)
- [1.2.2 Repository layout](1.2.2-repository-layout.md)
- [1.2.3 Installed layout](1.2.3-installed-layout.md)
- [1.2.4 Containers: hardening and resources](1.2.4-containers.md)
- [1.2.5 Templates](1.2.5-templates.md)
- [1.2.6 Targets and hardening](1.2.6-targets-and-hardening.md)
- [1.2.7 Privileges inventory (2.1.2.8)](1.2.7-container-inventory.md)
- [1.2.8 Security defaults](1.2.8-security-defaults.md)
- [1.2.9 Asking before fabric changes the host](1.2.9-host-consent.md)
- [1.2.10 Global options](1.2.10-global.md)
- [1.2.11 Networking and DNS](1.2.11-networking.md)
- [1.2.12 Docker infrastructure](1.2.12-docker.md)
- [1.2.13 What fabric claims, checked for collisions](1.2.13-name-claims.md)

## 1.3 fabricctl, setup and fabric-agent

- [1.3.1 The host package](1.3.1-host-package.md)
- [1.3.2 Setup: secure by default, scriptable](1.3.2-setup-design.md)
- [1.3.3 The fixed API](1.3.3-agent-api.md)

## 1.4 DNS: BIND

- [1.4.1 DNS architecture](1.4.1-dns-architecture.md)
- [1.4.2 Landing page links](1.4.2-landing-links.md)

## 1.5 Certificates: Step-CA

- [1.5.1 PKI chain and certificate relay](1.5.1-pki-chain.md)
- [1.5.2 PKI and certificates](1.5.2-pki.md)

## 1.6 Identity: the directory and sign-in

- [1.6.1 *[DELETED]* 389 Directory Server](1.6.1-directory.md)
- [1.6.2 Keycloak](1.6.2-keycloak.md)
- [1.6.3 The directory on Samba AD (design)](1.6.3-samba-directory.md)
- [1.6.4 [DEPRECATED] Samba AD beside fabric's directory](1.6.4-samba-ad.md)
- [1.6.5 Samba AD: the domain controller (design)](1.6.5-samba-dc.md)
- [1.6.6 Joining Linux machines to the domain](1.6.6-domain-join.md)
- [1.6.7 Joining Linux machines to AD (design)](1.6.7-linux-join-ad.md)
- [1.6.8 Access control for people across the stack](1.6.8-rbac.md)
- [1.6.9 The organisation and its directory](1.6.9-directory.md)
- [1.6.10 Security contexts and features](1.6.10-security.md)
- [1.6.11 Host access](1.6.11-host-access.md)
- [1.6.12 Domain management in the console](1.6.12-domain-management.md)
- [1.6.13 Access by groups and grants](1.6.13-access-by-grants.md)

## 1.7 Secrets: OpenBao

- [1.7.1 OpenBao](1.7.1-openbao.md)

## 1.8 The web UI

- [1.8.1 Architecture and components](1.8.1-webui-architecture.md)
- [1.8.2 Security model and who may do what](1.8.2-webui-security.md)
- [1.8.3 The web UI as the single pane](1.8.3-single-pane.md)
- [1.8.4 Web UI](1.8.4-webui.md)
- [1.8.5 The setup wizard: setup's choices in the console, and in a file](1.8.5-setup-wizard.md)
- [1.8.6 The console redone in Cockpit's style](1.8.6-console-redo.md)

## 1.9 Federation

- [1.9.1 Sites, terms and ownership](1.9.1-sites.md)
- [1.9.2 Services within a site: HA partners](1.9.2-ha-partners.md)
- [1.9.3 Services between sites](1.9.3-between-sites.md)
- [1.9.4 Joining and the federation endpoint](1.9.4-joining.md)
- [1.9.5 Attachment: flat, relay, nested](1.9.5-attachment.md)
- [1.9.6 What changes in fabric](1.9.6-changes.md)
- [1.9.7 Phases and milestones](1.9.7-milestones.md)
- [1.9.8 Federation on Samba AD (design)](1.9.8-federation-on-ad.md)

## 1.10 DHCP: Kea

- [1.10.1 Kea DHCP](1.10.1-kea-design.md)
- [1.10.2 DHCP management and the address plan](1.10.2-dhcp-management.md)
- [1.10.3 Serving networks beyond the host's LAN (0.8)](1.10.3-serving-networks.md)

## 1.11 802.1X: FreeRADIUS

- [1.11.1 FreeRADIUS](1.11.1-freeradius-design.md)

## 1.12 The DNS filter

- [1.12.1 [DEPRECATED] AdGuard Home in front of BIND](1.12.1-adguard.md)
- [1.12.2 The BIND resolver: filtering with response policy zones](1.12.2-bind-resolver.md)
- [1.12.3 AdGuard Home behind the resolver: the lists' matcher](1.12.3-adguard-behind-bind.md)

## 1.13 Time: chrony

- [1.13.1 Time for the site and its network](1.13.1-chrony.md)

## 1.14 Container images

- [1.14.1 Image channels](1.14.1-image-channels.md)
- [1.14.2 Image updates: validation and the host side](1.14.2-image-updates.md)
- [1.14.3 fabric's published images on hosts](1.14.3-published-images-on-hosts.md)

## 1.15 Log forwarding: Fluent Bit

- [1.15.1 Log forwarding](1.15.1-fluent-bit.md)

## 1.16 Disk encryption

- [1.16.1 LUKS unlocked by a security key](1.16.1-luks.md)

<!-- generated by scripts/docs/gen_lib_doc.py: 1.17 -->
## 1.17 Function reference

- [1.17.1 About the function reference](1.17.1-about-the-reference.md)
- [1.17.2 fabricctl-agent](1.17.2-fabricctl-agent.md) — fabric-agent: the permission-checked host API behind the web UI
- [1.17.3 fabricctl-jinja](1.17.3-fabricctl-jinja.md) — Code that runs inside service containers (the DC's converge code and operations, FreeRADIUS)
- [1.17.4 fabricctl-lib](1.17.4-fabricctl-lib.md) — Entry points: the deploy engine, the vars editor, the Keycloak configuration
- [1.17.5 fabriclib-common](1.17.5-fabriclib-common.md) — Shared helpers: paths, vars file, locking, audit, rendering, console output
- [1.17.6 fabriclib-consent](1.17.6-fabriclib-consent.md)
- [1.17.7 fabriclib-core](1.17.7-fabriclib-core.md) — fabriclib's command router (cli.py)
- [1.17.8 fabriclib-deploy](1.17.8-fabriclib-deploy.md) — The deploy engine: secrets, settings, render, install, restart
- [1.17.9 fabriclib-dhcp](1.17.9-fabriclib-dhcp.md) — Optional DHCP (Kea): settings, config, reservations, leases
- [1.17.10 fabriclib-dns](1.17.10-fabriclib-dns.md) — Zones, records, reverse zones, TSIG keys, ACLs, BIND reloads
- [1.17.11 fabriclib-dns_filter](1.17.11-fabriclib-dns_filter.md)
- [1.17.12 fabriclib-federation](1.17.12-fabriclib-federation.md)
- [1.17.13 fabriclib-images](1.17.13-fabriclib-images.md) — Container images: status, update with rollback, prune
- [1.17.14 fabriclib-keycloak](1.17.14-fabriclib-keycloak.md) — Keycloak: people, roles, sign-in resets, token verification
- [1.17.15 [DELETED] fabriclib-ldap](1.17.15-fabriclib-ldap.md)
- [1.17.16 fabriclib-logs](1.17.16-fabriclib-logs.md) — Optional log forwarding (Fluent Bit)
- [1.17.17 fabriclib-menu](1.17.17-fabriclib-menu.md) — The vars editor (fabricctl --interactive), --print and --apply
- [1.17.18 fabriclib-ntp](1.17.18-fabriclib-ntp.md) — Time: chrony on the host, its settings and checks
- [1.17.19 fabriclib-pki](1.17.19-fabriclib-pki.md) — Certificates: service certificates, manual issuing, CSR signing, conversion
- [1.17.20 fabriclib-radius](1.17.20-fabriclib-radius.md) — Optional 802.1X (FreeRADIUS): clients, groups, setup guides, decisions
- [1.17.21 fabriclib-rbac](1.17.21-fabriclib-rbac.md) — Who may do what: permissions, bundles, route table
- [1.17.22 fabriclib-secrets](1.17.22-fabriclib-secrets.md) — fabric's own secrets: file or OpenBao
- [1.17.23 fabriclib-security](1.17.23-fabriclib-security.md) — Host firewall for Docker-published ports
- [1.17.24 fabriclib-setup](1.17.24-fabriclib-setup.md) — fabricctl setup / doctor / uninstall / restore: one step per file
- [1.17.25 fabriclib-system](1.17.25-fabriclib-system.md) — Service status, start/stop, apply, version
- [1.17.26 fabriclib-undo](1.17.26-fabriclib-undo.md)
- [1.17.27 fabriclib-vault](1.17.27-fabriclib-vault.md) — OpenBao: unlock methods (key slots), status, rotation, OIDC, break glass
- [1.17.28 installers](1.17.28-installers.md) — The Debian package wrapper
- [1.17.29 webui](1.17.29-webui.md) — fabric-ctl web UI: server, pages, fabric-agent client, OIDC, CA-pinned TLS, dev preview
- [1.17.30 fabriclib-samba](1.17.30-fabriclib-samba.md)
- [1.17.31 fabriclib-directory](1.17.31-fabriclib-directory.md)
- [1.17.33 fabriclib-settings](1.17.33-fabriclib-settings.md)
- [1.17.34 fabriclib-breakglass](1.17.34-fabriclib-breakglass.md)
- [1.17.35 fabriclib-hostaccounts](1.17.35-fabriclib-hostaccounts.md)
- [1.17.36 fabriclib-grants](1.17.36-fabriclib-grants.md)
- [1.17.37 fabriclib-access](1.17.37-fabriclib-access.md)
- [1.17.38 fabriclib-domain](1.17.38-fabriclib-domain.md)
- [1.17.39 fabriclib-localadmin](1.17.39-fabriclib-localadmin.md)
<!-- end of generated 1.17 -->

## 1.18 STIG compliance

The home chapter for STIG compliance (Rule 5.8; 2.1.1.67).

- [1.18.1 STIG compliance: scope, the guides, and which part answers to which](1.18.1-stig-scope.md)
- [1.18.2 The STIG checklist: how compliance is recorded and proven](1.18.2-stig-checklist.md)
- [1.18.3 STIG baselines for the domain's members, by Group Policy](1.18.3-stig-gpo-baselines.md)

## Assets

[`assets/`](assets/README.md): data the chapters rest on (the STIG checklist).
