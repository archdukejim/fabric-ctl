from agent.read_strings import read_strings
from agent.read_text import read_text
from agent.read_tsig_edit import read_tsig_edit
from agent.route_not_found import RouteNotFound
from fabriclib.common.errors import ValidationError
from fabriclib.dns.add_record import add_record
from fabriclib.dns.add_zone import add_zone
from fabriclib.dns.constants import RECORD_TYPES
from fabriclib.dns.create_zone_tsig_key import create_zone_tsig_key
from fabriclib.dns.remove_record import remove_record
from fabriclib.dns.remove_tsig_key import remove_tsig_key
from fabriclib.dns.remove_zone import remove_zone
from fabriclib.dns.rotate_tsig_key import rotate_tsig_key
from fabriclib.dns.set_record_link import set_record_link
from fabriclib.dns.update_record import update_record
from fabriclib.dns.update_tsig_key import update_tsig_key


def _published(actor):
    """Purpose: A TSIG key made or given a new secret is done at once (2.1.8.17): BIND takes it now, through DNS' own
             deploy (dns/apply_dns, 2.1.8.24), so the secret shown once already works.
    Inputs:  actor — the verified user.
    Returns: {"published": True}, or {"published": False, "publish_error": why} (the key and its secret are saved
             either way: the secret is still shown once, and DNS' next Apply publishes it).
    Fails:   never for BIND's refusal (said in the answer).
    Feeds:   post_dns (tsig, tsig/<name>/rotate)."""
    from fabriclib.dns.apply_dns import apply_dns
    try:
        apply_dns(actor, source="web")
    except ValidationError as exc:
        return {"published": False, "publish_error": str(exc)}
    return {"published": True}


def post_dns(route, actor, data):
    """Purpose: DNS changes: POST /v1/zones/<key>/records[/delete|/update|/link] and
             /v1/tsig[/<name>/rotate|delete|update].
    Inputs:  route — segments after /v1/; actor — the verified user; data — the body: type, name, ip|target|… for a
             record (index for a delete; index, old_name and the new fields for an update; type, index, name,
             link, link_label, link_port, link_path for a landing-page link); name, zone, scope, hosts, types,
             secret, with_aliases for a TSIG key; add, drop, add_with_aliases, drop_with_aliases, scope,
             record_types for a key's Edit names (read_tsig_edit, 2.1.4.13).
    Returns: the new record; {"key", "secret", "ini", "published"[, "publish_error"]} for a new key (the secret shown
             once, BIND given it at once: _published); {"secret", "ini", "published"[, "publish_error"]} for a
             rotation; {} for a TSIG delete; {"key": the stored entry} for an edit (run at DNS' Apply, which
             publishes it: held, 2.1.8.18); remove_record's result for a record delete; update_record's ({old,
             new}) for an update; the record for a link.
    Fails:   ValidationError for an unsupported record type, an invalid index or what fabriclib refuses (-> 400);
             RouteNotFound for another route.
    Feeds:   agent/post_route.py."""
    if route == ["zones"]:
        hide = data.get("hide_public") in (True, "on", "true", "1")
        return add_zone(actor, read_text(data, "name"), hide_public=hide, source="web")
    if len(route) == 3 and route[0] == "zones" and route[2] == "delete":
        return remove_zone(actor, route[1], read_text(data, "confirm"), source="web")
    if len(route) == 3 and route[0] == "zones" and route[2] == "records":
        rtype = data.get("type", "")
        if rtype not in RECORD_TYPES:
            raise ValidationError("unsupported record type")
        return add_record(actor, route[1], rtype, data, source="web")
    if len(route) == 4 and route[0] == "zones" and route[2:] in (["records", "delete"], ["records", "link"],
                                                                        ["records", "update"]):
        try:
            index = int(data.get("index", -1))
        except (TypeError, ValueError):
            raise ValidationError("invalid index")
        if route[3] == "update":                   # a record replaced in place (2.1.4.15)
            fields = ("name", "value", "ip", "target", "text", "priority", "weight", "port", "vlan")
            return update_record(actor, route[1], str(data.get("type", "")), index, str(data.get("old_name", "")),
                                 {k: str(data.get(k) or "") for k in fields}, source="web")
        if route[3] == "link":
            return set_record_link(actor, route[1], str(data.get("type", "")), index, str(data.get("name", "")),
                                   {k: str(data.get(k) or "")
                                    for k in ("link", "link_label", "link_port", "link_path")},
                                   source="web")
        return remove_record(actor, route[1], str(data.get("type", "")), index, str(data.get("name", "")),
                             source="web")
    if route == ["tsig"]:
        key, secret, ini = create_zone_tsig_key(actor, read_text(data, "name"), read_text(data, "zone"),
                                                read_text(data, "scope"), read_strings(data, "hosts"),
                                                read_strings(data, "types"), read_text(data, "secret"), source="web",
                                                with_aliases=read_strings(data, "with_aliases"))
        return {"key": key, "secret": secret, "ini": ini, **_published(actor)}
    if len(route) == 3 and route[0] == "tsig" and route[2] == "rotate":
        secret, ini = rotate_tsig_key(actor, route[1], source="web")
        return {"secret": secret, "ini": ini, **_published(actor)}
    if len(route) == 3 and route[0] == "tsig" and route[2] == "delete":
        remove_tsig_key(actor, route[1], source="web")
        return {}
    if len(route) == 3 and route[0] == "tsig" and route[2] == "update":    # the secret kept (2.1.4.13)
        return {"key": update_tsig_key(actor, route[1], {}, source="web", edit=read_tsig_edit(data))}
    raise RouteNotFound()
