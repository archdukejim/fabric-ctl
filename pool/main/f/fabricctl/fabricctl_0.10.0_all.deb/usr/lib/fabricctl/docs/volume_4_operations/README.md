# Volume 4 — Operations

Operator workflows and end-user procedures. Chapter 4.C operates what chapter 1.C designs.

## 4.1 The product, and how it is built and released

Nothing here yet — nothing to operate on its own: see [1.1](../volume_1_description_and_architecture/README.md).

## 4.2 Architecture and the host

- [4.2.1 Resource use](4.2.1-resources.md)
- [4.2.2 Lifecycle commands](4.2.2-lifecycle.md)
- [4.2.3 Service ports](4.2.3-ports.md)
- [4.2.4 Moving the host to a new address, and renaming it](4.2.4-move-rename.md)

## 4.3 fabricctl, setup and fabric-agent

- [4.3.1 The fabricctl command](4.3.1-fabricctl.md)
- [4.3.6 Web-guided setup](4.3.6-web-guided-setup.md)
  - 4.3.6.1 Run Guided in the browser
  - 4.3.6.2 Trust fabric's root certificate
  - 4.3.6.3 Point a computer's DNS at fabric
  - 4.3.6.4 Troubleshoot the setup site
  - 4.3.6.5 Get the code back from another terminal
  - 4.3.6.6 Continue in another browser

## 4.4 DNS: BIND

- [4.4.1 Zones and records](4.4.1-records.md)
- [4.4.2 TSIG keys](4.4.2-tsig.md)
  - 4.4.2.1 TSIG Keys (RFC2136 dynamic updates)
  - 4.4.2.2 Make a key by its mode: ACME (DNS-01) or Custom
  - 4.4.2.3 Change a key's names, keeping its secret
  - 4.4.2.4 Grant a record with its aliases
- [4.4.3 ACLs and update policies](4.4.3-acls.md)
- [4.4.4 Landing page links](4.4.4-landing-links.md)
- [4.4.5 Reverse DNS](4.4.5-reverse-dns.md)

## 4.5 Certificates: Step-CA

- [4.5.1 Certificates from the command line](4.5.1-certificates.md)
- [4.5.2 Manual certificates in the web UI](4.5.2-manual-certificates.md)

## 4.6 Identity: the directory and sign-in

- [4.6.1 People and their identities](4.6.1-people.md)
- [4.6.2 Single sign-on for your apps](4.6.2-single-sign-on.md)
- [4.6.3 First-time setup](4.6.3-first-sign-in.md)
- [4.6.4 Sign-in security](4.6.4-sign-in-security.md)
- [4.6.5 The directory (Samba AD)](4.6.5-windows-domain.md)
- [4.6.6 Joining Linux machines](4.6.6-linux-join.md)
- [4.6.7 Joining Windows machines](4.6.7-windows-join.md)
- [4.6.8 Group Policy from ADMX templates](4.6.8-group-policy.md)
- [4.6.9 The administrators: break glass](4.6.9-administrators.md)
- [4.6.10 Who may do what, where: grants](4.6.10-grants.md)
- [4.6.11 Managing the directory: people, groups, OUs, computers, Kerberos](4.6.11-domain-management.md)

## 4.7 Secrets: OpenBao

- [4.7.1 OpenBao](4.7.1-openbao.md)

## 4.8 The web UI

- [4.8.1 Pages and features](4.8.1-features.md)
- [4.8.2 Device access](4.8.2-device-access.md)
- [4.8.3 The setup wizard and the settings file](4.8.3-setup-wizard.md)
- [4.8.4 Changes wait for Apply](4.8.4-apply.md)
- [4.8.5 My account](4.8.5-my-account.md)
- [4.8.6 Reaching a device's Cockpit through fabric](4.8.6-cockpit.md)
- 4.8.9 Console read cache — nothing to operate until 0.9.3 builds it: see [1.8.9](../volume_1_description_and_architecture/1.8.9-console-read-cache.md)

## 4.9 Federation

- [4.9.1 Sites](4.9.1-federation.md)
- [4.9.2 The address plan](4.9.2-address-plan.md)

## 4.10 DHCP: Kea

- [4.10.1 DHCP with Kea](4.10.1-dhcp.md)
- [4.10.2 The address manager (`fabricctl ipam`)](4.10.2-address-manager.md)

## 4.11 802.1X: FreeRADIUS

- [4.11.1 802.1X with FreeRADIUS](4.11.1-radius.md)

## 4.12 The DNS filter

- [4.12.1 The DNS filter](4.12.1-dns-filter.md)

## 4.13 Time: chrony

- [4.13.1 Time](4.13.1-time.md)

## 4.14 Container images

- [4.14.1 Images](4.14.1-images.md)

## 4.15 Log forwarding: Fluent Bit

- [4.15.1 Log forwarding](4.15.1-log-forwarding.md)

## 4.16 Disk encryption

Nothing here yet — nothing to operate on its own: see [1.16](../volume_1_description_and_architecture/README.md).

## 4.17 The function reference

Nothing here yet — nothing to operate on its own: see [1.17](../volume_1_description_and_architecture/README.md).

## 4.18 STIG compliance

Nothing here yet — nothing to operate until 0.11.0 builds it: see [1.18](../volume_1_description_and_architecture/README.md).
